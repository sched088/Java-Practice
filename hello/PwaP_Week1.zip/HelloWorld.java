/* *****************************************************************************
 *  Name:              Max Scheder
 *  Coursera User ID:
 *  Last modified:     January 1, 2021
 **************************************************************************** */

public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello, World");
    }
}
