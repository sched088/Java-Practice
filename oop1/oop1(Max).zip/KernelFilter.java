/* *****************************************************************************
 *  Name:              Alan Turing
 *  Coursera User ID:  123456
 *  Last modified:     1/1/2019
 **************************************************************************** */

import java.awt.Color;

public class KernelFilter {

    // Returns a new picture that applies the identity filter to the given picture.
    public static Picture identity(Picture picture) {
        double[][] weights = {
                { 0, 0, 0 },
                { 0, 1, 0 },
                { 0, 0, 0 },
                };

        return kernel(picture, weights);

    }

    // Returns a new picture that applies a Gaussian blur filter to the given picture.
    public static Picture gaussian(Picture picture) {
        double[][] weights = {
                { (double) 1 / 16, (double) 2 / 16, (double) 1 / 16 },
                { (double) 2 / 16, (double) 4 / 16, (double) 2 / 16 },
                { (double) 1 / 16, (double) 2 / 16, (double) 1 / 16 },
                };

        return kernel(picture, weights);

    }

    // Returns a new picture that applies a sharpen filter to the given picture.
    public static Picture sharpen(Picture picture) {
        double[][] weights = {
                { 0, -1, 0 },
                { -1, 5, -1 },
                { 0, -1, 0 },
                };

        return kernel(picture, weights);

    }

    // Returns a new picture that applies an Laplacian filter to the given picture.
    public static Picture laplacian(Picture picture) {
        double[][] weights = {
                { -1, -1, -1 },
                { -1, 8, -1 },
                { -1, -1, -1 },
                };

        return kernel(picture, weights);

    }

    // Returns a new picture that applies an emboss filter to the given picture.
    public static Picture emboss(Picture picture) {
        double[][] weights = {
                { -2, -1, 0 },
                { -1, 1, 1 },
                { 0, 1, 2 },
                };

        return kernel(picture, weights);

    }

    // Returns a new picture that applies a motion blur filter to the given picture.
    public static Picture motionBlur(Picture picture) {
        double[][] weights = {
                { (double) 1 / 9, 0, 0, 0, 0, 0, 0, 0, 0 },
                { 0, (double) 1 / 9, 0, 0, 0, 0, 0, 0, 0 },
                { 0, 0, (double) 1 / 9, 0, 0, 0, 0, 0, 0 },
                { 0, 0, 0, (double) 1 / 9, 0, 0, 0, 0, 0 },
                { 0, 0, 0, 0, (double) 1 / 9, 0, 0, 0, 0 },
                { 0, 0, 0, 0, 0, (double) 1 / 9, 0, 0, 0 },
                { 0, 0, 0, 0, 0, 0, (double) 1 / 9, 0, 0 },
                { 0, 0, 0, 0, 0, 0, 0, (double) 1 / 9, 0 },
                { 0, 0, 0, 0, 0, 0, 0, 0, (double) 1 / 9 },
                };

        return kernel(picture, weights);

    }

    // Returns a new picture that applies an arbitrary kernel filter to the given picture.
    private static Picture kernel(Picture picture, double[][] weights) {
        Picture transPic = new Picture(picture);
        // intent is to start at the top left and then iterate through the weighted matrix before iterating through the picture

        for (int col = 0; col < picture.width(); col++) {
            for (int row = 0; row < picture.height(); row++) {
                double cRed = 0;
                double cGreen = 0;
                double cBlue = 0;
                int wcenter = weights.length / 2;

                for (int wcol = 0; wcol < weights.length; wcol++) {
                    for (int wrow = 0; wrow < weights.length; wrow++) {
                        //                   if (col - 1 < 0) int coltemp = picture.width()
                        double trans = weights[wcol][wrow];


                        //this part sucked. Started with many if statements for edge conditions
                        //Math.floormod as per the FAQs was very hard for me to figure out and I
                        //had to utilize a number of online resources to figure it out.

                        int scol = Math.floorMod(col - wcenter + wcol, picture.width());
                        int srow = Math.floorMod(row - wcenter + wrow, picture.width());

                        Color color = picture.get(scol, srow);
                        int r = color.getRed();
                        int g = color.getGreen();
                        int b = color.getBlue();
                        cRed += r * trans;
                        cGreen += g * trans;
                        cBlue += b * trans;

                        if (cRed > 255) cRed = 255;
                        if (cGreen > 255) cGreen = 255;
                        if (cBlue > 255) cBlue = 255;
                        if (cRed < 0) cRed = 0;
                        if (cGreen < 0) cGreen = 0;
                        if (cBlue < 0) cBlue = 0;
                    }
                }
                Color c = new Color((int) cRed, (int) cGreen, (int) cBlue);
                transPic.set(col, row, c);
            }
        }
        return transPic;
    }

    // Test client (ungraded).
    public static void main(String[] args) {
        String file = args[0];
        //        In data = new In(file);
        Picture source = new Picture(file);

        Picture gaussian = gaussian(source);
        Picture sharpen = sharpen(source);
        Picture identity = identity(source);
        Picture laplacian = laplacian(source);
        Picture emboss = emboss(source);
        Picture motionBlur = motionBlur(source);

        identity.show();
        gaussian.show();
        sharpen.show();
        laplacian.show();
        emboss.show();
        motionBlur.show();
    }

}
